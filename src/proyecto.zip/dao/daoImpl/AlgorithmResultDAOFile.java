// Implementaciones concretas de DAO
package dao.daoImpl;

public class AlgorithmResultDAOFile implements dao.AlgorithmResultDAO {
    // Implementación que guarda en archivos
}