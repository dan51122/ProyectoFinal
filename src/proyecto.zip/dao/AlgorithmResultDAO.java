// Interfaces de acceso a datos
package dao;

public interface AlgorithmResultDAO {
    // Métodos para guardar y cargar resultados
}