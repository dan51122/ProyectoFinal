// Punto de entrada principal
public class MazeApp {
    public static void main(String[] args) {
        // Aquí inicia la aplicación
    }
}