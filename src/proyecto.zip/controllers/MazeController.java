// Controlador general de interacción entre vista y modelo
package controllers;

public class MazeController {
    // Lógica de control principal
}